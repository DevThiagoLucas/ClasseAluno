public class Teste {

    public static void main(String[] args) {
        //criação de um objeto
        
        Aluno aluno=new Aluno("java",7,8,9);

        if(aluno.aprovado()){

        }
        else{

        }
    }
    
}
